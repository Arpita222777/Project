package main;

import ui.LoginUI;

public class MainApp {
    public static void main(String[] args) {
        new LoginUI();
    }
}